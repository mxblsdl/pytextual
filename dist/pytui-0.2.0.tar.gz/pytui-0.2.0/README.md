# A markdown editor

I keep a daily log at work and wondered if I could create a markdown editor tailored to how I use my log. Experimenting with the textual framework.

Can be used by installing and using the command `log` in the console.
The log will automatically save and append new dates to itself. There is also a binding for viewing your markdown as rendered markdown with `crtl+n`.

## Improvements
- Add delete line functionality
- make key bindings more intuitive
- check on links loading external sites
- explore find functionality